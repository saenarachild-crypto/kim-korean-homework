
import { GoogleGenAI, Type } from "@google/genai";
import { LearnerData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `당신은 한국어 수능/EBS 문제지를 디지털 인터랙티브 HTML로 변환하는 전문가입니다.
제공된 파일을 분석하여 다음 지침에 따라 데이터를 추출하세요.

[추출 지침]
1. 지문 정보
   - 문항 범위 표시 (예: "[01~04] 다음 글을 읽고 물음에 답하시오.")
   - 본문 단락: 들여쓰기와 줄바꿈을 최대한 보존하세요.
   - 밑줄 조건: ㉠㉡㉢㉣㉤ 등으로 표시된 구절은 <u class="ul-mark">내용</u> 태그로 감싸세요.
   - 괄호 구간: [A], [B] 등은 <span class="bracket">내용</span> 태그로 감싸세요.
   - 각주: ※ 기호로 시작하는 설명을 포함하세요.

2. 문항 구조
   - 문항 번호, 문항 코드(있으면), 발문(질문 본문)을 추출하세요.
   - <보기>가 있는 경우 별도로 추출하세요.
   - 선택지 ①②③④⑤와 각 텍스트를 배열로 추출하세요.
   - 정답 번호(1~5)를 정확히 확인하세요.
   - 정답 해설: 왜 맞는지 1~2문장으로 요약하세요.
   - 오답 안내: 틀렸을 때 보여줄 메시지를 작성하세요.

응답은 오직 JSON 형식으로만 출력하세요.`;

export async function extractWeeklyContent(
  categories: { schedule: File[], reading: File[], literature: File[], explanation: File[] },
  fullPackageName: string
): Promise<Partial<LearnerData>[]> {
  const model = "gemini-3-pro-preview";
  const parts: any[] = [{ text: SYSTEM_INSTRUCTION }];

  const addFilesToParts = async (files: File[], label: string) => {
    if (files.length === 0) return;
    parts.push({ text: `--- [${label} 데이터] ---` });
    for (const file of files) {
      const base64 = await fileToBase64(file);
      parts.push({ text: `파일명: ${file.name}` });
      parts.push({
        inlineData: { data: base64, mimeType: file.type }
      });
    }
  };

  await addFilesToParts(categories.schedule, "스케줄표");
  await addFilesToParts(categories.reading, "독서");
  await addFilesToParts(categories.literature, "문학");
  await addFilesToParts(categories.explanation, "해설");

  parts.push({ text: `${fullPackageName} 패키지를 생성하세요. 스케줄표에 명시된 Day 1~5의 모든 지문을 JSON 배열로 반환하세요.` });

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            dayNumber: { type: Type.INTEGER },
            title: { type: Type.STRING },
            passage: { type: Type.STRING },
            sourceFileId: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  num: { type: Type.INTEGER },
                  code: { type: Type.STRING },
                  text: { type: Type.STRING },
                  bogi: { type: Type.STRING, nullable: true },
                  options: { type: Type.ARRAY, items: { type: Type.STRING } },
                  answer: { type: Type.INTEGER },
                  explanation: {
                    type: Type.OBJECT,
                    properties: {
                      correct: { type: Type.STRING },
                      wrong: { type: Type.STRING }
                    },
                    required: ["correct", "wrong"]
                  }
                },
                required: ["num", "text", "options", "answer", "explanation"]
              }
            }
          },
          required: ["dayNumber", "title", "passage", "questions"]
        }
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("AI 분석 결과가 비어있습니다.");
  try {
    return JSON.parse(text);
  } catch (e) {
    console.error("JSON Error:", text);
    throw new Error("AI가 5일치 분량을 구성하는 중 JSON 규격을 위반했습니다.");
  }
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = reject;
  });
}
