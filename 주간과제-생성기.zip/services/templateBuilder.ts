
import { WeeklyConfig } from "../types";

export function buildWeeklyLearnerHTML(config: WeeklyConfig): string {
  const safeData = JSON.stringify(config).replace(/<\/script>/gi, '<\\/script>');

  return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${config.packageName}</title>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@400;700;900&family=Noto+Sans+KR:wght@300;400;500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #f5f0e8;          /* 크림색 배경 */
      --paper: #fefcf7;       /* 카드 배경 */
      --ink: #1a1612;         /* 본문 텍스트 */
      --ink-light: #4a4540;   /* 보조 텍스트 */
      --rule: #c8bfaa;        /* 구분선 */
      --accent: #2c4a7c;      /* 포인트 네이비 */
      --accent-light: #d4e0f0;
      --correct: #2d6a4f;     /* 정답 초록 */
      --correct-bg: #d8f3dc;
      --wrong: #9b2335;       /* 오답 빨강 */
      --wrong-bg: #fde8ea;
      --selected: #1a3560;    /* 선택됨 파랑 */
      --selected-bg: #dce8f7;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
    body { 
      font-family: 'Noto Sans KR', sans-serif; 
      background-color: var(--bg); 
      color: var(--ink); 
      line-height: 1.6;
      word-break: keep-all;
    }
    .serif { font-family: 'Noto Serif KR', serif; }
    
    header {
      position: sticky;
      top: 0;
      background-color: var(--accent);
      color: white;
      padding: 12px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 100;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    .header-title { font-size: 0.9rem; font-weight: 700; }
    .header-score { font-size: 1.1rem; font-weight: 900; font-family: monospace; }
    .btn-reset { 
      background: rgba(255,255,255,0.2); 
      border: none; 
      color: white; 
      padding: 4px 12px; 
      border-radius: 20px; 
      font-size: 0.75rem; 
      cursor: pointer;
      font-weight: 700;
    }

    main { max-width: 900px; margin: 0 auto; padding: 20px; }

    .dashboard { display: block; }
    .passage-view { display: none; }

    .day-section { margin-bottom: 40px; }
    .day-title { 
      font-size: 1.5rem; 
      font-weight: 900; 
      color: var(--accent); 
      margin-bottom: 15px; 
      border-bottom: 2px solid var(--accent);
      display: inline-block;
      padding-right: 20px;
    }
    .set-card {
      background: var(--paper);
      border: 1px solid var(--rule);
      border-radius: 16px;
      padding: 20px;
      margin-bottom: 12px;
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
    }
    .set-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    .set-card h3 { font-size: 1.1rem; font-weight: 700; margin-bottom: 4px; }
    .set-card p { font-size: 0.85rem; color: var(--ink-light); }

    .passage-box {
      background: var(--paper);
      border-left: 4px solid var(--accent);
      padding: 30px;
      margin-bottom: 30px;
      border-radius: 0 16px 16px 0;
      box-shadow: 0 2px 10px rgba(0,0,0,0.03);
      font-size: 1.1rem;
    }
    .passage-box p { margin-bottom: 1.2em; text-indent: 1em; }
    .passage-box p:first-child { text-indent: 0; font-weight: 700; color: var(--accent); }
    
    .question-card {
      background: var(--paper);
      border: 1px solid var(--rule);
      border-radius: 16px;
      margin-bottom: 25px;
      overflow: hidden;
      animation: fadeIn 0.5s ease-out;
    }
    .q-header {
      background-color: var(--accent);
      color: white;
      padding: 15px 20px;
      display: flex;
      align-items: flex-start;
      gap: 15px;
    }
    .q-num {
      background: white;
      color: var(--accent);
      width: 28px;
      height: 28px;
      min-width: 28px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 900;
      font-size: 0.9rem;
    }
    .q-title { flex: 1; font-weight: 700; font-size: 1rem; line-height: 1.4; }
    .q-code { font-size: 0.7rem; opacity: 0.7; font-family: monospace; margin-top: 4px; }
    .q-status { font-size: 1.2rem; }

    .bogi-box {
      background: #f2ede4;
      border: 1px solid var(--rule);
      margin: 20px;
      padding: 20px;
      border-radius: 8px;
      font-size: 0.95rem;
      line-height: 1.7;
    }
    .bogi-box::before { content: "〈보기〉"; display: block; font-weight: 900; margin-bottom: 10px; text-align: center; }

    .options-list { padding: 10px 20px 20px; }
    .opt-btn {
      width: 100%;
      text-align: left;
      background: white;
      border: 1px solid var(--rule);
      padding: 14px 18px;
      margin-bottom: 10px;
      border-radius: 10px;
      cursor: pointer;
      display: flex;
      gap: 12px;
      font-size: 1rem;
      transition: all 0.2s;
    }
    .opt-btn:hover { background: var(--bg); }
    .opt-btn.selected { background: var(--selected-bg); border-color: var(--selected); color: var(--selected); font-weight: 700; }
    .opt-btn.correct { background: var(--correct-bg); border-color: var(--correct); color: var(--correct); font-weight: 700; animation: flash-correct 0.5s; }
    .opt-btn.wrong { background: var(--wrong-bg); border-color: var(--wrong); color: var(--wrong); animation: shake 0.4s; }
    .opt-btn b { min-width: 22px; }

    .result-bar {
      display: none;
      padding: 20px;
      margin: 0 20px 20px;
      border-radius: 12px;
      font-size: 0.9rem;
      animation: fadeIn 0.3s;
    }
    .result-bar.show { display: block; }
    .result-bar.is-correct { background: var(--correct-bg); border: 1px solid var(--correct); color: var(--correct); }
    .result-bar.is-wrong { background: var(--wrong-bg); border: 1px solid var(--wrong); color: var(--wrong); }
    .res-title { font-weight: 900; margin-bottom: 6px; display: block; }

    .final-score {
      display: none;
      background: var(--accent);
      color: white;
      padding: 40px;
      border-radius: 24px;
      text-align: center;
      margin-top: 40px;
      animation: fadeIn 0.8s;
    }
    .final-score h2 { font-size: 2rem; font-weight: 900; margin-bottom: 10px; }
    .final-score p { font-size: 1.1rem; opacity: 0.9; margin-bottom: 25px; }
    .progress-container { background: rgba(255,255,255,0.2); height: 12px; border-radius: 6px; overflow: hidden; margin-bottom: 20px; }
    .progress-bar { background: white; height: 100%; width: 0%; transition: width 1s ease-out; }

    u.ul-mark { text-decoration: none; border-bottom: 2px solid var(--accent); background: rgba(44, 74, 124, 0.1); padding: 0 2px; }
    .bracket { border: 1px solid var(--rule); padding: 0 4px; border-radius: 4px; background: rgba(0,0,0,0.03); }
    i { font-style: italic; }

    @keyframes flash-correct {
      0% { transform: scale(1); }
      40% { transform: scale(1.02); }
      100% { transform: scale(1); }
    }
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      20% { transform: translateX(-6px); }
      60% { transform: translateX(6px); }
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 600px) {
      main { padding: 10px; }
      .passage-box { padding: 20px; font-size: 1rem; }
      .q-header { padding: 12px 15px; }
      .opt-btn { padding: 12px 15px; font-size: 0.9rem; }
    }
  </style>
</head>
<body>

<header>
  <div class="header-title serif" id="header-title">${config.packageName}</div>
  <div style="display: flex; align-items: center; gap: 15px;">
    <div class="header-score" id="score-display">0 / 0</div>
    <button class="btn-reset" onclick="resetAll()">↺ 초기화</button>
  </div>
</header>

<main>
  <div id="dashboard" class="dashboard">
    <div id="dashboard-content"></div>
  </div>

  <div id="passage-view" class="passage-view">
    <button onclick="showDashboard()" style="margin-bottom: 20px; background: none; border: 1px solid var(--accent); color: var(--accent); padding: 8px 16px; border-radius: 8px; cursor: pointer; font-weight: 700;">← 목록으로</button>
    <div id="passage-content"></div>
    <div id="questions-content"></div>
    <div id="final-panel" class="final-score">
      <h2 class="serif">학습 완료!</h2>
      <p id="final-msg">수고하셨습니다.</p>
      <div class="progress-container"><div id="final-progress" class="progress-bar"></div></div>
      <button onclick="showDashboard()" class="btn-reset" style="padding: 12px 30px; font-size: 1rem;">다른 지문 학습하기</button>
    </div>
  </div>
</main>

<script>
  const CONFIG = ${safeData};
  const state = {
    activeSetId: null,
    answers: {},
    score: 0,
    total: 0
  };

  function init() {
    renderDashboard();
  }

  function renderDashboard() {
    const content = document.getElementById('dashboard-content');
    content.innerHTML = '';
    
    for (let d = 1; d <= 5; d++) {
      const sets = CONFIG.sets.filter(s => s.dayNumber === d);
      if (sets.length === 0) continue;
      
      const section = document.createElement('div');
      section.className = 'day-section';
      section.innerHTML = \`<div class="day-title serif">DAY \${d}</div>\`;
      
      sets.forEach(set => {
        const card = document.createElement('div');
        card.className = 'set-card';
        card.innerHTML = \`
          <h3>\${set.title}</h3>
          <p>\${set.questions.length}문항</p>
        \`;
        card.onclick = () => loadPassage(set.setId);
        section.appendChild(card);
      });
      content.appendChild(section);
    }
  }

  function loadPassage(setId) {
    const set = CONFIG.sets.find(s => s.setId === setId);
    if (!set) return;
    
    state.activeSetId = setId;
    state.answers = {};
    state.score = 0;
    state.total = set.questions.length;
    
    document.getElementById('header-title').textContent = set.title;
    updateScore();
    
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('passage-view').style.display = 'block';
    document.getElementById('final-panel').style.display = 'none';
    
    // Render Passage
    const pContent = document.getElementById('passage-content');
    pContent.innerHTML = \`
      <div class="passage-box serif">
        \${set.passage.split('\\n').map(p => p.trim() ? \`<p>\${p}</p>\` : '').join('')}
      </div>
    \`;
    
    // Render Questions
    const qContent = document.getElementById('questions-content');
    qContent.innerHTML = '';
    
    set.questions.forEach(q => {
      const card = document.createElement('div');
      card.className = 'question-card';
      card.id = \`q-card-\${q.num}\`;
      
      let html = \`
        <div class="q-header">
          <div class="q-num">\${q.num}</div>
          <div class="q-title">
            \${q.text}
            \${q.code ? \`<div class="q-code">[\${q.code}]</div>\` : ''}
          </div>
          <div class="q-status" id="status-\${q.num}">○</div>
        </div>
      \`;
      
      if (q.bogi) {
        html += \`<div class="bogi-box">\${q.bogi}</div>\`;
      }
      
      html += \`<div class="options-list">\`;
      q.options.forEach((opt, idx) => {
        const n = idx + 1;
        html += \`
          <button class="opt-btn" id="opt-\${q.num}-\${n}" onclick="answer(\${q.num}, \${n}, \${q.answer})">
            <b>\${['①','②','③','④','⑤'][idx]}</b>
            <span>\${opt}</span>
          </button>
        \`;
      });
      html += \`</div>\`;
      
      html += \`
        <div class="result-bar" id="res-\${q.num}">
          <span class="res-title" id="res-title-\${q.num}"></span>
          <span id="res-body-\${q.num}"></span>
        </div>
      \`;
      
      card.innerHTML = html;
      qContent.appendChild(card);
    });
    
    window.scrollTo(0, 0);
  }

  function answer(qNum, chosen, correct) {
    if (state.answers[qNum] !== undefined) return;
    
    state.answers[qNum] = chosen;
    const isCorrect = chosen === correct;
    if (isCorrect) state.score++;
    
    const set = CONFIG.sets.find(s => s.setId === state.activeSetId);
    const q = set.questions.find(qu => qu.num === qNum);
    
    // Update UI
    const statusIcon = document.getElementById(\`status-\${qNum}\`);
    statusIcon.textContent = isCorrect ? '✓' : '✗';
    statusIcon.style.color = isCorrect ? 'var(--correct-bg)' : 'var(--wrong-bg)';
    
    const chosenBtn = document.getElementById(\`opt-\${qNum}-\${chosen}\`);
    if (isCorrect) {
      chosenBtn.classList.add('correct');
    } else {
      chosenBtn.classList.add('wrong');
      document.getElementById(\`opt-\${qNum}-\${correct}\`).classList.add('correct');
    }
    
    // Disable other buttons
    for (let i = 1; i <= 5; i++) {
      const btn = document.getElementById(\`opt-\${qNum}-\${i}\`);
      if (btn) btn.style.cursor = 'default';
    }
    
    // Show Result Bar
    const resBar = document.getElementById(\`res-\${qNum}\`);
    const resTitle = document.getElementById(\`res-title-\${qNum}\`);
    const resBody = document.getElementById(\`res-body-\${qNum}\`);
    
    resBar.classList.add('show');
    resBar.classList.add(isCorrect ? 'is-correct' : 'is-wrong');
    resTitle.textContent = isCorrect ? '정답입니다!' : '아쉽네요, 오답입니다.';
    resBody.textContent = isCorrect ? q.explanation.correct : q.explanation.wrong;
    
    updateScore();
    
    if (Object.keys(state.answers).length === state.total) {
      showFinal();
    }
  }

  function updateScore() {
    document.getElementById('score-display').textContent = \`\${state.score} / \${state.total}\`;
  }

  function showFinal() {
    const panel = document.getElementById('final-panel');
    const msg = document.getElementById('final-msg');
    const progress = document.getElementById('final-progress');
    
    panel.style.display = 'block';
    const percent = (state.score / state.total) * 100;
    
    if (percent === 100) msg.textContent = "완벽합니다! 모든 문제를 맞히셨습니다.";
    else if (percent >= 80) msg.textContent = "훌륭합니다! 조금만 더 하면 만점이에요.";
    else if (percent >= 50) msg.textContent = "잘 하셨습니다. 틀린 문제를 다시 확인해 보세요.";
    else msg.textContent = "포기하지 마세요! 다시 한 번 지문을 꼼꼼히 읽어봅시다.";
    
    setTimeout(() => {
      progress.style.width = percent + '%';
    }, 100);
    
    panel.scrollIntoView({ behavior: 'smooth' });
  }

  function showDashboard() {
    document.getElementById('dashboard').style.display = 'block';
    document.getElementById('passage-view').style.display = 'none';
    document.getElementById('header-title').textContent = CONFIG.packageName;
    document.getElementById('score-display').textContent = '0 / 0';
  }

  function resetAll() {
    if (confirm('모든 학습 기록을 초기화하시겠습니까?')) {
      if (state.activeSetId) {
        loadPassage(state.activeSetId);
      } else {
        location.reload();
      }
    }
  }

  init();
</script>

</body>
</html>`;
}
